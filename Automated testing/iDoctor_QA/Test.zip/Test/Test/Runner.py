import pytest


if __name__ == '__main__':

    pytest.main(['--html=report.html', '--self-contained-html'])
