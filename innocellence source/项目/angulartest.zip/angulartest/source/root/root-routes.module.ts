import { NgModule } from "@angular/core";
import { Route, RouterModule } from "@angular/router";
import { LoginComponent } from "./login/login.component";
import { RoleComponent } from "./role/role.component";

const routes: Route[] = [
  { path: "login", component: LoginComponent },
  { path: "roles", component: RoleComponent },
];

@NgModule({
  exports: [RouterModule],
  imports: [RouterModule.forRoot(routes)],
})
export class RootRoutesModule {}
