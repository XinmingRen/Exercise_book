import { json } from "../../../../Users/XinMing.Ren/AppData/Local/Microsoft/TypeScript/3.2/node_modules/@types/body-parser";

$(function() {
  //  just  a test!
  //点击login发送ajax请求后台user数据，返回数据与前台的文本框进行验证判断
  $("#submit-login").on("click", function() {
    $.ajax({
      type: "get",
      url: "/user",
      data: { username: $("#username").val(), password: $("#password").val() },
      dataType: "json",
      success: function(response) {
        JSON.stringify(data);
        if (
          $("#username")
            .val()
            .equal(data.username) &&
          $("#password")
            .val()
            .equal(data.password)
        ) {
          alert("login success ");
        }
      },
      error: function() {
        alert("sorry,wrong");
      },
    });
  });
});
