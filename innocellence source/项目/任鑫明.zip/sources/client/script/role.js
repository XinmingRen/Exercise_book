//js初始加载即进行下列的增删筛查
$(function() {
  getRoles();
  saveRoles();
  deleteRole();
  editRole();
});
//获得数据来填充表格getusers
function getRoles() {
  $.ajax({
    data: {},
    dataType: "json",
    type: "get",
    url: "/role",
    success: function(data) {
      //先行清空tbody数据
      $("#list").empty();
      let item;
      JSON.stringify(data);
      $.each(data, function(i, result) {
        content =
          "<tr>" +
          "<td>" +
          result.id +
          "</td>" +
          "<td>" +
          result.roleName +
          "</td>" +
          "<td>" +
          "<button id='edit' type='button' class='btn btn-info btn-sm' " +
          " style='margin:0 5px' onclick='updateRole(" +
          result +
          ")'>edit</button>" +
          "<button id='delete' type='button' class='btn btn-danger btn-sm' onclick='deleteRole(" +
          result.id +
          ")'>delete</button></td>" +
          "</tr>";
        $("#list").append(content);
      });
    },
    error: function() {
      alert("err");
    },
  });
}
//模态框的用户信息提交==>即增加用户save
$("#save").on("click", function() {
  var roleid = $("#roleid").val();
  var rolename = $("#rolename").val();

  var content = { roleid: roleid, rolename: rolename };
  $.ajax({
    url: "/role",
    dataType: "json",
    method: "post",
    data: content,
    success: function() {
      getRoles();
      alert("add success");
      $("#myModal").modal("hide");
    },
    error: function() {
      alert("添加失败，请检查问题");
    },
  });
});
//删除用户信息;
//通过在获得users时append的时候就在button里增加点击事件  nice！
function deleteRole(id) {
  if (confirm("do you want to delete this messsage?  really?")) {
    $.ajax({
      type: "delete",
      //  dataType: "json",
      url: "role/" + id,
      success: function(data) {
        if (data) {
          alert("已成功删除一条用户信息");
          getRoles(); //删除后再回到展示页面
        }
      },
      error: function() {
        alert("sorry,there are somethings going wrong!!");
      },
    });
  }
}
//修改编辑用户信息;       同delete方式
//通过在获得users时append的时候就在button里增加点击事件  nice！
// function updateRole(result) {
//   $("#myModal").modal("show"); //让模态框显示
//   //因为要编辑，将数据先显示在相应的文本框中
//   $("#roleid").val(result.roleId);
//   $("#rolename").val(result.roleName);

//   $("#edit").on("click", function() {
//     $.ajax({
//       type: "put",
//       url: "role/",
//       data: {
//         roleId: $("#roleid").val(),
//         roleName: $("#rolename").val(),
//
//       },

//       success: function() {
//         alert("修改成功！");
//         getRoles();
//       },
//       error: function() {
//         alert("sorry,deit failed");
//       },
//     });
//   });
// }
