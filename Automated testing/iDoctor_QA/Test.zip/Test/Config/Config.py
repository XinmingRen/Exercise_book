
iDoctorBackendURL = "https://idoctorchinawechat-qa.xh3.lilly.com/account/login"


ChromeUsesrAgent="user-agent=Mozilla/5.0 (Linux; U; Android 2.3.6; zh-cn; GT-S5660 Build/GINGERBREAD) AppleWebKit/533.1 (KHTML, like Gecko) Version/4.0 Mobile Safari/533.1 MicroMessenger/4.5.255"

AirScriptsPath='D:/Jingyuan.Gao/workspace/Claire/AirScripts.air/'
AirScriptsPathforUsing='D:\\Jingyuan.Gao\\workspace\\Claire\\AirScripts.air\\'
AndroidDevice='V4DQSCBE6DGQWKH6'
AndroidURL='http://127.0.0.1:4723/wd/hub'
PNGPath='D:\\Jingyuan.Gao\\workspace\\Claire\\Config\\PNG\\'
DB_Config={
            'host':'192.168.***.**',
             'user':'***',
            'password':'****'
            }
