import { Column, Entity, JoinColumn, PrimaryGeneratedColumn } from "typeorm";

export { Entity } from "typeorm";
@Entity({ name: "Role" })
export class Role {
  // 建表  自增主键列ID：number
  @PrimaryGeneratedColumn()
  public id: number;
  // roleName字段列  指定字段类型与最大长度
  @Column("varchar", { length: 100 })
  public roleName: string;
}
