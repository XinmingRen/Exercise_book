import { Module } from "@nestjs/common";
import { TypeOrmModule } from "@nestjs/typeorm";
import passport = require("passport");
import { Entity } from "typeorm";
import { AppController } from "./app.controller";
import { RoleController, RoomController } from "./controllers";
import { MeetingController } from "./controllers/meeting.controller";
import { UserController } from "./controllers/user.controller";
import { Meeting } from "./entities/meeting.entity";
import { Role } from "./entities/role.entity";
import { Room } from "./entities/room.entity";
import { User } from "./entities/user.entity";
// 装饰符 表明是module【模块】
@Module({
  // 在controller里加载指明各个controller才能知道模块里有哪些controller
  controllers: [
    AppController,
    UserController,
    RoomController,
    MeetingController,
    RoleController,
  ],
  // 链接数据库 此处写数据库信息
  // 数据库明文后期通过.env写入环境变量
  imports: [
    TypeOrmModule.forRoot({
      database: "test",
      entities: [User, Role, Meeting, Room], // 对应相应的实体
      host: "localhost\\SQLEXPRESS01",
      logging: true,
      password: "admin",
      port: 1433,
      synchronize: true, // 开启同步，可以将实体entity的字段直接在数据库建表同步
      type: "mssql", // type表明链接的哪种数据库，typeorm可以链接多种数据库
      username: "renxinming",
    }),
    TypeOrmModule.forFeature([User, Room, Role, Meeting]),
  ],
})
export class AppModule {}
