require("ts-node/register");
require("./server-src/app");
