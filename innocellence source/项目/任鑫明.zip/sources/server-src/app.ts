import { NestFactory } from "@nestjs/core";
import cookieParser = require("cookie-parser");
import passport = require("passport");
import { AppModule } from "./app.module";

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  app.useStaticAssets(`${process.cwd()}\\client`);
  await app.listen(3000);
}

bootstrap();
