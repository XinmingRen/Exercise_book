import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";

export { Entity } from "typeorm";
@Entity({ name: "Meeting" })
export class Meeting {
  // 建表  自增主键列ID：number
  @PrimaryGeneratedColumn()
  public id: number;
  // meetingname字段列  指定字段类型与最大长度
  @Column("varchar", { length: 100 })
  public meetingName: string;
  // meeeting  info字段列  指定字段类型与最大长度
  @Column("varchar", { length: 100, nullable: true })
  public info: string;
}
