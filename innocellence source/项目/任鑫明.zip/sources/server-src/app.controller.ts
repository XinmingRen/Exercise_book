import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
} from "@nestjs/common";

@Controller("app")
export class AppController {
  // 定义一个对对象数组来存储数据当做数据源
  public user: any[] = [
    {
      id: 1,
      name: "jack",
    },
    {
      id: 2,
      name: "jerry",
    },
    {
      id: 3,
      name: "monkey",
    },
  ];
  // users/:id    路由规则要用：表示，实际URL则不用
  // users/1?name=zhangsan
  // params{id:1}
  // query{name:zahngsan}
  // body {}
  @Get(":id")
  // 查一个--->id
  public getoneuser(@Param("id") id: number) {
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < this.user.length; i++) {
      const userId = this.user[i].id;
      if (userId === id) {
        return this.user[id];
      }
    }
  }
  @Get()
  // // 查所有
  public getallusers() {
    return this.user;
  }

  // users/:id    路由格式写法
  // users/1?id=2   URL写法
  // query={ID：2}    query为对象格式应为{ }形式
  // params={id:1}
  @Post()
  // 增
  public adduser(@Body() user1: any) {
    // 定义一个user1对象为下
    user1 = { id: 4, name: "rose" };
    // tslint:disable-next-line:prefer-for-of
    // for (let i = 0; i < this.user.length; i++) {
    //   const userId = this.user[i].id;
    //   if (user1.id === userId) {
    //     // alert("当前已存在该id，无法添加该id的对象");
    //     user1 = { id: 5, name: "kkkk" };
    //     this.user.push(user1);
    //   } else {
    this.user.push(user1);
    //   }
    // }
    return this.user;
  }

  // users/:id
  // users/1

  @Put(":id")
  // 改  更新
  public updata(@Param("id") id, @Query("name") username: any) {
    // 假设更改的内容；
    id = 3;
    username = "pony";
    // 由于tslint的存在，不知道为什么写for循环就会飘红，但是多了下面一行就解决了。【应该是属于更改了tslint的配置文件】
    // tslint:disable-next-line:prefer-for-of
    for (let i = 0; i < this.user.length; i++) {
      const userid = this.user[i].id;
      if (userid === id) {
        this.user[i].name = username;
      }
    }
    return this.user[id];
  }

  @Delete(":id")
  // 删除
  public delete(@Param("id") id: any) {
    id = 3;
    for (let i = 0; i < this.user.length; i++) {
      const userId = this.user[i].id;
      if (id === userId) {
        this.user.splice(i, 1);
      }
    }
    return this.user;
  }
}
