import {
  Column,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Role } from "./role.entity";

export { Entity } from "typeorm";
@Entity({ name: "User" }) // 这里的User才代表实际数据库的表名
// 这个class User代表userentity   类
export class User {
  // 建表  自增主键列ID：number
  @PrimaryGeneratedColumn()
  public id: number;
  // name字段列  指定字段类型与最大长度
  @Column("varchar", { length: 100 })
  public userName: string;
  // 密码字段
  @Column("varchar", { length: 100 })
  public password: string;
  // 昵称字段
  @Column("varchar", { length: 100 })
  public nickName: string;
  // 多对多关系
  // @ManyToMany(() => Role)
  // public roles: Role;
}
