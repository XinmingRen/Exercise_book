import ATFPackage.ATF
import pytest
# from Test.useATF import BaiDuSearch
# from Config import chromeBrowser
#
# class TestBaidu():
#     def test_baidu(self,chromeBrowser):
#         BaiDuSearch(chromeBrowser).SearchinBaidu()


if __name__ == '__main__':
    pytest.main()
