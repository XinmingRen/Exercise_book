import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Meeting } from "./meeting.entity";

export { Entity } from "typeorm";
@Entity({ name: "Room" })
export class Room {
  // 建表
  @PrimaryGeneratedColumn()
  public id: number;
  // roomName字段列  指定字段类型与最大长度
  @Column("varchar", { length: 100 })
  public roomname: string;
  // commont字段列  指定字段类型与最大长度100
  @Column("varchar", { length: 100, nullable: true })
  public commont: string;
  // manytoone  关系
  @ManyToOne(() => Meeting)
  public meeting: Meeting;
}
