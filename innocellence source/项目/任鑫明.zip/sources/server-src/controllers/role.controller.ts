import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
} from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { Role } from "../entities";
import { Room } from "./../entities/room.entity";

@Controller("role")
export class RoleController {
  // 依赖注入要写在构造函数里
  constructor(
    @InjectRepository(Role) private readonly roomRepository: Repository<Role>,
  ) {}

  @Get(":id")
  // 查一个--->id
  public async getoneuser(@Param("id") id: number) {
    return await this.roomRepository.findOne(id);
  }
  @Get()
  // // 查所有
  public async getallusers() {
    return await this.roomRepository.find();
  }

  // users/:id    路由格式写法
  // users/1?id=2   URL写法
  // query={ID：2}    query为对象格式应为{ }形式
  // params={id:1}
  @Post()
  // 增
  public async adduser(@Body() role: any) {
    return await this.roomRepository.save(role);
  }

  @Put(":id")
  // 改  更新 t
  public async updata(@Param("id") id: any, @Body() role: any) {
    return await this.roomRepository.update(id, role);
  }

  @Delete(":id")
  // 删除
  public async delete(@Param("id") id: any) {
    return await this.roomRepository.delete(id);
  }
}
