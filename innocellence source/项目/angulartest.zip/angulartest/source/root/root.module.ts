import { CommonModule } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgZorroAntdModule } from "ng-zorro-antd";
import { LoginComponent } from "./login/login.component";
import { RoleComponent } from "./role/role.component";
import { RootRoutesModule } from "./root-routes.module";
import { RootComponent } from "./root.component";

@NgModule({
  bootstrap: [RootComponent],
  declarations: [RootComponent, LoginComponent, RoleComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    RootRoutesModule,
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgZorroAntdModule,
  ],
})
export class RootModule {}
