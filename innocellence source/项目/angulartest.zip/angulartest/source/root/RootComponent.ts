import { Component } from "@angular/core";
@Component({
  selector: "web-root",
  templateUrl: "./root.template.html",
})
export class RootComponent {
}
