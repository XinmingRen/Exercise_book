//js初始加载即进行下列的增删筛查
$(function() {
  getMeetings();
  saveMeeting();
  deleteUser();
  editMeeting();
});
//获得数据来填充表格getusers
function getMeetings() {
  $.ajax({
    data: {},
    dataType: "json",
    type: "get",
    url: "/meeting",
    success: function(data) {
      //先行清空tbody数据
      $("#list").empty();
      let item;
      JSON.stringify(data);
      $.each(data, function(i, result) {
        content =
          "<tr>" +
          "<td>" +
          result.id +
          "</td>" +
          "<td>" +
          result.meetingName +
          "</td>" +
          "<td>" +
          "<button id='edit' type='button' class='btn btn-info btn-sm' " +
          " style='margin:0 5px' onclick='updateMeeting(" +
          result +
          ")'>edit</button>" +
          "<button id='delete' type='button' class='btn btn-danger btn-sm' onclick='deleteMeeting(" +
          result.id +
          ")'>delete</button></td>" +
          "</tr>";
        $("#list").append(content);
      });
    },
    error: function() {
      alert("err");
    },
  });
}
//模态框的用户信息提交==>即增加用户save
$("#save").on("click", function() {
  var meetingName = $("#meetingname").val();

  var content = { meetingName: meetingname };
  $.ajax({
    url: "/meeting",
    dataType: "json",
    method: "post",
    data: content,
    success: function() {
      getMeetings();
      alert("add success");
      $("#myModal").modal("hide");
    },
    error: function() {
      alert("添加失败，请检查问题");
    },
  });
});
//删除用户信息;
//通过在获得users时append的时候就在button里增加点击事件  nice！
function deleteMeeeting(id) {
  if (confirm("do you want to delete this messsage?  really?")) {
    $.ajax({
      type: "delete",
      //  dataType: "json",
      url: "meeting/" + id,
      success: function(data) {
        if (data) {
          alert("已成功删除一条用户信息");
          getMeetings(); //删除后再回到展示页面
        }
      },
      error: function() {
        alert("sorry,there are somethings going wrong!!");
      },
    });
  }
}
//修改编辑用户信息;       同delete方式
//通过在获得users时append的时候就在button里增加点击事件  nice！
// function updateMeeting(result) {
//   $("#myModal").modal("show"); //让模态框显示
//   //因为要编辑，将数据先显示在相应的文本框中
//   $("#id").val(result.id);
//   $("#meetingname").val(result.meetingName);

//   $("#edit").on("click", function() {
//     $.ajax({
//       type: puts,
//       url: "meeting/",
//       data: {
//         username: $("#id").val(),
//         password: $("#meetingName").val(),

//       },

//       success: function() {
//         alert("修改成功！");
//         getMeetings();
//       },
//       error: function() {
//         alert("sorry,deit failed");
//       },
//     });
//   });
// }
