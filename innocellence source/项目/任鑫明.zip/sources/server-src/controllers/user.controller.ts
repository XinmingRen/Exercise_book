import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
} from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import bodyParser = require("body-parser");
import { Repository } from "typeorm";
import { User } from "./../entities/user.entity";
// 路由规则：  @controller（）括号里的“user”就是url里的localhost：3000/user
@Controller("user")
export class UserController {
  // 依赖注入要写在构造函数里
  constructor(
    @InjectRepository(User) private readonly userRepository: Repository<User>,
  ) {}
  @Get(":id")
  // 查一个--->id
  public async getOneuser(@Param("id") id: number) {
    return await this.userRepository.findOne(id);
  }
  // localhost:3000/users/2
  @Get()
  // // 查所有
  public async getAllUsers() {
    return await this.userRepository.find();
  }

  @Post() // postman选post localhost:3000/user/   在body里（x-wwwform-urllencoded）填写字段信息,即增加一条信息
  // 增
  public async adduser(@Body() user: any) {
    return await this.userRepository.save(user);
  }

  @Put(":id")
  // 改  更
  public async updateUser(@Param("id") id: any, @Body() user: any) {
    // 传参问题：put和post只能用@body（），且只写一个@body（），后面直接跟改的对象
    return await this.userRepository.update(id, user);
  }

  @Delete(":id") // postman选delete localhost:3000/user/3   即删除id为3的信息
  // 删除
  public async delete(@Param("id") id: any) {
    return await this.userRepository.delete(id);
  }
}
