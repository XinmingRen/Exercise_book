import { HttpClient } from "@angular/common/http";
import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

@Component({
  templateUrl: "./login.template.html",
})
export class LoginComponent implements OnInit {
  public validateForm: FormGroup;

  constructor(
    private readonly httpClient: HttpClient,
    private readonly formBuilder: FormBuilder,
  ) {}

  public ngOnInit(): void {
    this.validateForm = this.formBuilder.group({
      password: [null, [Validators.required]],
      username: [null, [Validators.required]],
    });
  }

  public async submitForm(): Promise<void> {
    // tslint:disable-next-line:forin
    for (const i in this.validateForm.controls) {
      this.validateForm.controls[i].markAsDirty();
      this.validateForm.controls[i].updateValueAndValidity();
    }
    if (!this.validateForm.invalid) {
      const result = await this.httpClient
        .post("/auth/login", this.validateForm.value)
        .toPromise();
    }
  }
}
